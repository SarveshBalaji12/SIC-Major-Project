import requests
from bs4 import BeautifulSoup

rss_index_url = "https://kannada.news18.com/rss/"

resp = requests.get(rss_index_url)
resp.raise_for_status()

soup = BeautifulSoup(resp.text, "html.parser")
# Find all links under the RSS listing
rss_links = [
    a["href"]
    for a in soup.select("a[href*='/rss/']")
    if a["href"].endswith(".xml")
]
# Deduplicate & ensure absolute URLs
rss_links = list({requests.compat.urljoin(rss_index_url, u) for u in rss_links})

# print("Discovered RSS feeds:")
# for link in rss_links:
#     print(link)


import feedparser
import pandas as pd

records = []

for feed_url in rss_links:
    feed = feedparser.parse(feed_url)
    for entry in feed.entries:
        records.append({
            "title"     : entry.title,
            "link"      : entry.link,
            "pubDate"   : getattr(entry, "published", ""),
            "category"  : getattr(entry, "category", ""),
            "summary"   : entry.get("summary", "").strip()
        })

# Build a DataFrame
df = pd.DataFrame(records)
print(df.head())


df.drop_duplicates(subset=["link"], inplace=True)
df["pubDate"] = pd.to_datetime(df["pubDate"])
df.to_csv("kannada_news_headlines.csv", index=False)
