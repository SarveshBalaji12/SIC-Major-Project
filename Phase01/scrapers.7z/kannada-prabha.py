import argparse
import csv
import re
import time
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup


BASE_URL = "https://www.kannadaprabha.com"
BASE_API = BASE_URL + "/api/v1/collections/{category}"
HEADERS = {
	"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
	"(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
	"Accept": "text/html,application/json;q=0.9,*/*;q=0.8",
}


def try_get_json(url: str, timeout: int = 15):
	try:
		r = requests.get(url, headers=HEADERS, timeout=timeout)
		if r.status_code == 200 and r.headers.get("content-type", "").startswith("application/json"):
			return r.json()
		# Sometimes APIs respond with JSON but a text content-type
		if r.status_code == 200:
			try:
				return r.json()
			except Exception:
				return None
		return None
	except Exception:
		return None


def discover_categories_from_sections() -> list[str]:
	"""Try to discover category slugs from possible sections APIs (Quintype-like)."""
	candidates_endpoints = [
		BASE_URL + "/api/v1/sections",
		BASE_URL + "/api/sections",
		BASE_URL + "/api/v1/menu",
		BASE_URL + "/api/menu",
	]

	slugs: list[str] = []
	for url in candidates_endpoints:
		data = try_get_json(url)
		if not data:
			continue
		# API can be list, or object with 'sections' or 'items'
		if isinstance(data, list):
			for s in data:
				slug = (s.get("slug") or s.get("section-slug") or s.get("id") or "").strip("/")
				if slug:
					slugs.append(slug)
		elif isinstance(data, dict):
			container = data.get("sections") or data.get("items") or data.get("data") or []
			if isinstance(container, list):
				for s in container:
					if not isinstance(s, dict):
						continue
					slug = (s.get("slug") or s.get("section-slug") or s.get("id") or "").strip("/")
					if slug:
						slugs.append(slug)
	# Validate via collections API
	valid = []
	seen = set()
	for slug in sorted(set(slugs)):
		if slug in seen:
			continue
		seen.add(slug)
		test_url = BASE_API.format(category=slug) + "?limit=1&offset=0&item-type=story"
		j = try_get_json(test_url)
		if j and isinstance(j, dict) and j.get("items"):
			valid.append(slug)
	return valid


def is_single_segment_path(path: str) -> bool:
	parts = [p for p in path.split("/") if p]
	return len(parts) == 1


def discover_categories_from_homepage() -> list[str]:
	"""Fallback: parse homepage for top-level section links and validate."""
	try:
		r = requests.get(BASE_URL + "/", headers=HEADERS, timeout=20)
		if r.status_code != 200:
			return []
		soup = BeautifulSoup(r.text, "html.parser")
		hrefs = set()
		for a in soup.find_all("a", href=True):
			href = a["href"]
			# Normalize
			if href.startswith("//"):
				href = "https:" + href
			if href.startswith("/"):
				href = urljoin(BASE_URL, href)
			if not href.startswith(BASE_URL):
				continue
			path = urlparse(href).path
			if path and is_single_segment_path(path):
				slug = path.strip("/")
				if slug and len(slug) >= 3:
					hrefs.add(slug)

		# Common non-category paths to exclude
		blacklist = {"", "amp", "latest", "photos", "videos", "live", "epaper", "privacy-policy", "terms-of-use"}

		candidates = sorted({h for h in hrefs if h not in blacklist})

		valid = []
		for slug in candidates:
			# Prefer API validation
			j = try_get_json(BASE_API.format(category=slug) + "?limit=1&offset=0&item-type=story")
			if j and j.get("items"):
				valid.append(slug)
				continue
			# Fallback: check category page has multiple article links
			url = f"{BASE_URL}/{slug}"
			try:
				rr = requests.get(url, headers=HEADERS, timeout=20)
				if rr.status_code != 200:
					continue
				page = BeautifulSoup(rr.text, "html.parser")
				links = extract_article_links_from_listing(page, base=BASE_URL, category_slug=slug)
				if len(links) >= 5:
					valid.append(slug)
			except Exception:
				pass
		return valid
	except Exception:
		return []


def discover_all_categories() -> list[str]:
	slugs = discover_categories_from_sections()
	if slugs:
		print(f"Discovered {len(slugs)} categories via sections API.")
		return slugs
	print("Sections API not available; falling back to homepage discovery...")
	slugs = discover_categories_from_homepage()
	print(f"Discovered {len(slugs)} categories via homepage.")
	return slugs


def fetch_articles_api(category: str, limit: int = 50, max_pages: int = 1000) -> list[dict]:
	articles: list[dict] = []
	for page in range(max_pages):
		offset = page * limit
		url = BASE_API.format(category=category) + f"?limit={limit}&offset={offset}&item-type=story"
		resp = requests.get(url, headers=HEADERS, timeout=20)
		if resp.status_code != 200:
			if page == 0:
				print(f"API unavailable for '{category}' (status {resp.status_code}).")
			break
		try:
			data = resp.json()
		except Exception:
			break
		items = data.get("items", [])
		if not items:
			if page == 0:
				print(f"No items from API for '{category}'.")
			break
		for item in items:
			story = item.get("story", {}) if isinstance(item, dict) else {}
			headline = story.get("headline") or story.get("title")
			surl = story.get("url") or story.get("slug") or ""
			if surl and surl.startswith("/"):
				surl = urljoin(BASE_URL, surl)
			published = story.get("published-at") or story.get("first-published-at")
			if headline and surl:
				articles.append({
					"headline": headline,
					"url": surl,
					"published": published,
					"category": category,
				})
		print(f"[API] {category}: +{len(items)} at offset {offset}")
	return articles


def extract_article_links_from_listing(soup: BeautifulSoup, base: str, category_slug: str | None = None) -> list[tuple[str, str]]:
	"""Return list of (headline, url) from a listing page soup."""
	out: list[tuple[str, str]] = []
	seen = set()

	# Heuristics: look for anchors inside article/list item cards
	selectors = [
		"article a[href]",
		"h2 a[href]",
		"h3 a[href]",
		".story-card a[href]",
		".listing a[href]",
		".section-list a[href]",
		"li a[href]",
	]

	for sel in selectors:
		for a in soup.select(sel):
			href = a.get("href")
			if not href:
				continue
			text = (a.get_text(strip=True) or "").strip()
			if href.startswith("//"):
				href = "https:" + href
			if href.startswith("/"):
				href = urljoin(base, href)
			if not href.startswith(base):
				continue
			path = urlparse(href).path
			# Skip category index links
			if is_single_segment_path(path):
				continue
			# If category slug provided, prefer links containing it
			if category_slug and ("/" + category_slug + "/") not in path:
				# Allow if looks like an article (has date or id digits)
				if not re.search(r"/\d{4}/|/\d{6,}/|-(?:news|article)-?\d+", path):
					continue
			key = (text, href)
			if text and href and key not in seen:
				out.append((text, href))
				seen.add(key)

	return out


def fetch_articles_html(category: str, max_pages: int = 50) -> list[dict]:
	"""Scrape listing pages for a given category using HTML parsing.
	Tries common paginations like ?page=N and ?p=N.
	"""
	articles: list[dict] = []
	urls_to_try_patterns = [
		f"{BASE_URL}/{category}",
		f"{BASE_URL}/{category}?page={{n}}",
		f"{BASE_URL}/{category}?p={{n}}",
	]

	seen_urls = set()
	page_num = 1
	empty_in_a_row = 0

	while page_num <= max_pages and empty_in_a_row < 2:
		got_any = False
		for patt in urls_to_try_patterns:
			url = patt.format(n=page_num)
			try:
				r = requests.get(url, headers=HEADERS, timeout=25)
			except Exception:
				continue
			if r.status_code != 200:
				continue
			soup = BeautifulSoup(r.text, "html.parser")
			pairs = extract_article_links_from_listing(soup, base=BASE_URL, category_slug=category)
			added_now = 0
			for headline, href in pairs:
				if href not in seen_urls:
					articles.append({
						"headline": headline,
						"url": href,
						"published": "",
						"category": category,
					})
					seen_urls.add(href)
					added_now += 1
			if added_now:
				got_any = True
				print(f"[HTML] {category}: +{added_now} at page {page_num} via {url}")
		if not got_any:
			empty_in_a_row += 1
		else:
			empty_in_a_row = 0
		page_num += 1

	return articles


def save_csv(articles: list[dict], output_file: str) -> None:
	with open(output_file, "w", encoding="utf-8", newline="") as f:
		writer = csv.DictWriter(f, fieldnames=["headline", "url", "published", "category"])
		writer.writeheader()
		writer.writerows(articles)
	print(f"\n✅ Collected {len(articles)} articles. Saved to {output_file}")


def main():
	parser = argparse.ArgumentParser(description="Scrape Kannada Prabha headlines across categories")
	parser.add_argument("--category", type=str, default="science-technology", help="Category slug (e.g., science-technology, sports)")
	parser.add_argument("--limit", type=int, default=50, help="Articles per request (API mode)")
	parser.add_argument("--max-pages", type=int, default=100, help="Max pages/offsets to fetch per category")
	parser.add_argument("--output", type=str, default="kannada_prabha_headlines.csv", help="Output CSV filename")
	parser.add_argument("--all", action="store_true", help="Discover and scrape all categories")
	parser.add_argument("--delay", type=float, default=0.5, help="Delay (seconds) between categories")
	args = parser.parse_args()

	def scrape_one(cat: str) -> list[dict]:
		# Prefer API if available
		test = try_get_json(BASE_API.format(category=cat) + "?limit=1&offset=0&item-type=story")
		if test and test.get("items"):
			return fetch_articles_api(category=cat, limit=args.limit, max_pages=args.max_pages)
		return fetch_articles_html(category=cat, max_pages=args.max_pages)

	if args.all:
		cats = discover_all_categories()
		if not cats:
			print("⚠️ Could not discover categories.")
			return
		combined: list[dict] = []
		seen = set()
		print(f"Scraping {len(cats)} categories...")
		for i, cat in enumerate(cats, start=1):
			print(f"\n[{i}/{len(cats)}] Category: {cat}")
			try:
				arts = scrape_one(cat)
			except Exception as e:
				print(f"Error fetching '{cat}': {e}")
				arts = []
			added = 0
			for a in arts:
				if a["url"] not in seen:
					combined.append(a)
					seen.add(a["url"])
					added += 1
			print(f"Added {added} unique articles from '{cat}'.")
			time.sleep(args.delay)
		if combined:
			save_csv(combined, args.output)
		else:
			print("⚠️ No articles fetched from any category.")
	else:
		arts = scrape_one(args.category)
		if arts:
			save_csv(arts, args.output)
		else:
			print("⚠️ No articles fetched.")


if __name__ == "__main__":
	main()

