import requests
import csv
import argparse
import re
import time

BASE_API = "https://www.prajavani.net/api/v1/collections/{category}"
BASE_URL = "https://www.prajavani.net/"
HEADERS = {"User-Agent": "Mozilla/5.0"}

def discover_categories_from_sections():
    """Try to discover category slugs from the sections API."""
    url = "https://www.prajavani.net/api/v1/sections"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        if resp.status_code != 200:
            return []
        data = resp.json()
        # API may return a list or an object with 'sections'
        sections = data if isinstance(data, list) else data.get("sections", [])
        slugs = []
        for s in sections:
            slug = s.get("slug") or s.get("section-slug") or s.get("id")
            if slug:
                slugs.append(str(slug).strip("/"))
        # Validate each slug has a non-empty collection
        valid = []
        for slug in sorted(set(slugs)):
            test_url = f"{BASE_API.format(category=slug)}?limit=1&offset=0&item-type=story"
            r = requests.get(test_url, headers=HEADERS, timeout=15)
            if r.status_code == 200:
                try:
                    j = r.json()
                    if j.get("items"):
                        valid.append(slug)
                except Exception:
                    pass
        return valid
    except Exception:
        return []

def discover_categories_from_homepage():
    """Fallback: scrape homepage links, derive last path segment as candidate slug, and validate."""
    try:
        resp = requests.get(BASE_URL, headers=HEADERS, timeout=15)
        if resp.status_code != 200:
            return []
        html = resp.text
        hrefs = set(re.findall(r'href="(/[^"#?]+)"', html))
        candidates = set()
        for href in hrefs:
            parts = href.strip("/").split("/")
            if not parts:
                continue
            slug = parts[-1]
            if len(slug) >= 3 and all(c.isalnum() or c in "-_" for c in slug):
                candidates.add(slug)
        valid = []
        for slug in sorted(candidates):
            test_url = f"{BASE_API.format(category=slug)}?limit=1&offset=0&item-type=story"
            r = requests.get(test_url, headers=HEADERS, timeout=15)
            if r.status_code == 200:
                try:
                    j = r.json()
                    if j.get("items"):
                        valid.append(slug)
                except Exception:
                    pass
        return valid
    except Exception:
        return []

def discover_all_categories():
    """Auto-discover categories from sections API, with homepage fallback."""
    slugs = discover_categories_from_sections()
    if slugs:
        print(f"Discovered {len(slugs)} categories via sections API.")
        return slugs
    print("Sections API did not return usable slugs; falling back to homepage discovery...")
    slugs = discover_categories_from_homepage()
    print(f"Discovered {len(slugs)} categories via homepage.")
    return slugs

def fetch_articles(category="agriculture", limit=50, max_pages=1000):
    articles = []
    for page in range(max_pages):
        offset = page * limit
        url = f"{BASE_API.format(category=category)}?limit={limit}&offset={offset}&item-type=story"
        resp = requests.get(url, headers=HEADERS)
        if resp.status_code != 200:
            print(f"Error {resp.status_code} at offset {offset} for '{category}', stopping.")
            break

        data = resp.json()
        items = data.get("items", [])
        if not items:
            print(f"No more items at offset {offset} for '{category}', stopping.")
            break

        for item in items:
            story = item.get("story", {})
            headline = story.get("headline")
            url = "https://www.prajavani.net" + story.get("url", "")
            published = story.get("published-at")
            articles.append({
                "headline": headline,
                "url": url,
                "published": published,
                "category": category  # keep slug for clarity
            })

        print(f"Fetched {len(items)} items at offset {offset} for '{category}'")

    return articles

def save_csv(articles, output_file):
    with open(output_file, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["headline", "url", "published", "category"])
        writer.writeheader()
        writer.writerows(articles)
    print(f"\n✅ Collected {len(articles)} articles. Saved to {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Scrape Prajavani headlines via API")
    parser.add_argument("--category", type=str, default="agriculture", help="News category (e.g., agriculture, sports, politics)")
    parser.add_argument("--limit", type=int, default=50, help="Articles per request")
    parser.add_argument("--max-pages", type=int, default=1000, help="Maximum number of requests")
    parser.add_argument("--output", type=str, default="prajavani_headlines.csv", help="Output CSV filename")
    parser.add_argument("--all", action="store_true", help="Discover and scrape all categories")
    parser.add_argument("--delay", type=float, default=0.5, help="Delay (seconds) between category requests to be polite")
    args = parser.parse_args()

    if args.all:
        categories = discover_all_categories()
        if not categories:
            print("⚠️ Could not discover categories.")
            raise SystemExit(1)
        combined = []
        seen_urls = set()
        print(f"Scraping {len(categories)} categories...")
        for i, cat in enumerate(categories, start=1):
            print(f"\n[{i}/{len(categories)}] Category: {cat}")
            try:
                arts = fetch_articles(category=cat, limit=args.limit, max_pages=args.max_pages)
            except Exception as e:
                print(f"Error fetching '{cat}': {e}")
                arts = []
            added = 0
            for a in arts:
                if a["url"] not in seen_urls:
                    combined.append(a)
                    seen_urls.add(a["url"])
                    added += 1
            print(f"Added {added} unique articles from '{cat}'.")
            time.sleep(args.delay)
        if combined:
            save_csv(combined, args.output)
        else:
            print("⚠️ No articles fetched from any category.")
    else:
        articles = fetch_articles(category=args.category, limit=args.limit, max_pages=args.max_pages)
        if articles:
            save_csv(articles, args.output)
        else:
            print("⚠️ No articles fetched.")


# gadget-news-technology
# uv run python scrape_prajavani.py --category gadget-news-technology --limit 50 --max-pages 1000 --output tech.csv

# tech-tips-technology
# uv run python scrape_prajavani.py --category tech-tips-technology --limit 50 --max-pages 1000 --output tech_tips.csv

# all categories (auto-discover)
# uv run python scrape_prajavani.py --all --limit 50 --max-pages 20000 --output all_prajavani.csv
