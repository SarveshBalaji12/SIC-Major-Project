#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Vijaya Karnataka headline collector with auto-msid discovery.
- First tries config endpoint for msids.
- If none found, fetches homepage HTML and regex all "articlelist/<msid>.cms".
- Scrapes headlines with pagination (curpg + pg.tp).
- Deduplicates headlines, outputs CSV.
"""

import argparse, csv, sys, re, hashlib, os
import requests
from urllib.parse import urlencode

BASE = "https://vkfeed.indiatimes.com/langapi/listing.cms"
CONFIG_URL = "https://vkfeed.indiatimes.com/langapi/config?property=vk&template=allsections_nav"
HOMEPAGE = "https://vijaykarnataka.com/"

SEED_MSIDS = [10765232, 48343674, 71478549, 73171695, 50075603, 10738503, 57869229, 10738520, 60023487]

def norm_text(s: str) -> str:
    return " ".join((s or "").strip().lower().split())

def fetch_page(session, msid: int, page: int, perpage: int = 100):
    params = {"msid": msid, "perpage": perpage, "curpg": page}
    url = f"{BASE}?{urlencode(params)}"
    try:
        r = session.get(url, timeout=15)
        if r.status_code != 200:
            return {}
        data = r.json()
        if isinstance(data, dict) and "items" in data:
            data["_source_url"] = url
            data["_msid"] = msid
            return data
    except Exception as e:
        sys.stderr.write(f"[warn] fetch_page failed msid={msid} pg={page}: {e}\n")
    return {}

def collect_from_msid(msid: int, session, target: int, seen_hashes: set, rows: list, notify_every: int = 10000):
    page, secname_cache, total_pages = 1, None, None
    while True:
        data = fetch_page(session, msid, page)
        items = data.get("items", [])
        if secname_cache is None:
            secname_cache = data.get("secname") or str(msid)
        if total_pages is None:
            try:
                total_pages = int(data.get("pg", {}).get("tp", 0))
            except Exception:
                total_pages = None
        if not items:
            break
        for it in items:
            hl = it.get("hl") or it.get("title") or it.get("headline")
            if not hl: continue
            lu, item_id = it.get("lu"), it.get("id")
            key = hashlib.sha1(norm_text(hl).encode("utf-8")).hexdigest()
            if key in seen_hashes: continue
            seen_hashes.add(key)
            rows.append({
                "headline": hl,
                "datetime": lu,
                "category": secname_cache,
                "section_msid": msid,
                "item_id": item_id,
            })
            if len(seen_hashes) % notify_every == 0:
                print(f"[progress] {len(seen_hashes):,} unique headlines collected...")
            if target and len(seen_hashes) >= target:
                return True
        page += 1
        if total_pages and page > total_pages:
            break
    return False

def auto_discover_msids(session):
    msids = []
    # try config endpoint
    try:
        r = session.get(CONFIG_URL, timeout=10)
        if r.status_code == 200:
            data = r.json()
            def recurse(obj):
                if isinstance(obj, dict):
                    if "msid" in obj and str(obj["msid"]).isdigit():
                        msids.append(int(obj["msid"]))
                    for v in obj.values(): recurse(v)
                elif isinstance(obj, list):
                    for v in obj: recurse(v)
            recurse(data)
    except Exception as e:
        sys.stderr.write(f"[warn] config endpoint failed: {e}\n")
    if msids:
        return sorted(set(msids))
    # fallback: scrape homepage
    try:
        r = session.get(HOMEPAGE, timeout=10)
        if r.status_code == 200:
            html = r.text
            found = re.findall(r"articlelist/(\d+)\.cms", html)
            msids.extend(int(x) for x in found)
    except Exception as e:
        sys.stderr.write(f"[warn] homepage scrape failed: {e}\n")
    return sorted(set(msids))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="vk_headlines.csv")
    ap.add_argument("--target", type=int, default=0)
    ap.add_argument("--auto", action="store_true")
    ap.add_argument("--dedupe-against", nargs="*", default=[], help="CSV files to load and exclude headlines from (by normalized text)")
    ap.add_argument("--target-new", type=int, default=0, help="Collect this many NEW unique headlines beyond those in --dedupe-against and existing --out")
    ap.add_argument("--append", action="store_true", help="Append only new rows to --out instead of overwriting. If file doesn't exist, header will be written.")
    args = ap.parse_args()

    session = requests.Session()
    session.headers.update({"User-Agent": "Mozilla/5.0 (compatible; VKHeadlinesCollector/3.0)"})

    if args.auto:
        msid_list = auto_discover_msids(session)
        print(f"[info] Auto-discovered {len(msid_list)} msids: {msid_list[:15]}{'...' if len(msid_list)>15 else ''}")
    else:
        msid_list = SEED_MSIDS
        print(f"[info] Using seed msids: {msid_list}")

    # Seed dedupe set from provided CSVs and optionally existing output file
    def norm_hash(text: str) -> str:
        return hashlib.sha1(norm_text(text).encode("utf-8")).hexdigest()

    seen_hashes, rows = set(), []

    preload_files = list(args.dedupe_against or [])
    if os.path.exists(args.out):
        # If appending or using target-new, it's helpful to avoid duplicates against existing output
        preload_files.append(args.out)

    def load_existing_csvs(file_paths):
        loaded_total = 0
        for p in file_paths:
            try:
                if not os.path.isfile(p):
                    continue
                loaded_file = 0
                with open(p, "r", encoding="utf-8", newline="") as f:
                    # Try DictReader first
                    pos = f.tell()
                    dr = csv.DictReader(f)
                    used_dict = False
                    if dr.fieldnames and ("headline" in dr.fieldnames or "title" in dr.fieldnames):
                        used_dict = True
                        for row in dr:
                            text = row.get("headline") or row.get("title")
                            if not text:
                                continue
                            seen_hashes.add(norm_hash(text))
                            loaded_file += 1
                    if not used_dict:
                        # Fallback: plain CSV, take first column
                        f.seek(pos)
                        rr = csv.reader(f)
                        header_peek = next(rr, None)
                        if header_peek is None:
                            continue
                        # Heuristic: if header has 'headline', skip it
                        if header_peek and any(h.lower() == "headline" for h in header_peek):
                            # Process remaining rows
                            for row in rr:
                                if not row:
                                    continue
                                seen_hashes.add(norm_hash(row[0]))
                                loaded_file += 1
                        else:
                            # Treat peeked row as data
                            if header_peek:
                                seen_hashes.add(norm_hash(header_peek[0]))
                                loaded_file += 1
                            for row in rr:
                                if not row:
                                    continue
                                seen_hashes.add(norm_hash(row[0]))
                                loaded_file += 1
                loaded_total += loaded_file
                print(f"[info] Preloaded {loaded_file:,} headlines from {p}")
            except Exception as e:
                sys.stderr.write(f"[warn] Failed to preload from {p}: {e}\n")
        return loaded_total

    pre_count = load_existing_csvs(preload_files)
    base_count = len(seen_hashes)
    baseline_hashes = set(seen_hashes)
    if pre_count:
        print(f"[info] Dedupe baseline: {base_count:,} existing headlines")

    # Compute the stopping target considering preloaded dedupe
    effective_target = args.target
    if args.target_new and args.target_new > 0:
        effective_target = base_count + args.target_new
        print(f"[info] Targeting {args.target_new:,} NEW headlines (overall target = {effective_target:,})")
    elif args.target and args.target > 0 and base_count > 0:
        print(f"[info] Overall target requested = {args.target:,} (current baseline {base_count:,})")
    for msid in msid_list:
        stop = collect_from_msid(msid, session, effective_target, seen_hashes, rows)
        if stop: break

    # Dedup rows from this run and also ensure none collide with preloaded set
    final, seen_texts = [], set()
    for r in rows:
        key_text = norm_text(r["headline"])
        key_hash = hashlib.sha1(key_text.encode("utf-8")).hexdigest()
        # Skip if duplicate within this run or already present in baseline
        if key_text in seen_texts or key_hash in baseline_hashes:
            # skip duplicates inside this run or accidental collisions (already in baseline)
            continue
        seen_texts.add(key_text)
        final.append(r)

    new_count = len(final)
    total_after = base_count + new_count
    if args.target_new:
        print(f"[done] New headlines this run: {new_count:,} | Baseline: {base_count:,} | Total (baseline+new): {total_after:,}")
    else:
        print(f"[done] Total unique headlines collected this run (excluding preloaded): {new_count:,}")

    # Save results
    fieldnames = ["headline","datetime","category","section_msid","item_id"]
    write_header = True
    mode = "w"
    if args.append:
        mode = "a"
        write_header = not os.path.exists(args.out) or os.path.getsize(args.out) == 0
    with open(args.out, mode, newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if write_header:
            writer.writeheader()
        writer.writerows(final)
    action = "appended to" if args.append else "saved to"
    print(f"[saved] {new_count:,} new rows {action} {args.out}")

if __name__ == "__main__":
    main()
